# Tina Qiu

import pygame
import pytmx
import time
import random
from pytmx import load_pygame
pygame.init()
clock = pygame.time.Clock()



# game class: game state switcher
class Game():
    def __init__(self):
        self.state = "main" # start with main scene (the map)
        self.userinput = ""
        self.index = 0
        self.q = []
        self.a = []
        self.inventory = []
        self.battled = False
        self.done = False

    def main(self):        
        animal.a_health = 100   # reset health after battle
        player.p_health = 100
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.state = ""
                self.done = True
            if event.type == pygame.MOUSEBUTTONDOWN:
                click_pos = pygame.mouse.get_pos()
                if click_pos[0] in range(bag.rect.x, bag.rect.x+225) and (click_pos[1] in range(bag.rect.y, bag.rect.y+110)):
                    self.state = "inventory"
        # drawing code
        screen.fill('#71ddee')
        camera_group.update()
        sprite_group.update()
        bushes_group.update()
        boundary_group.update()
        camera_group.custom_draw(player)
        bag.draw(screen)

        # check collisions with bushes_group
        collision_bushes = pygame.sprite.spritecollide(player, bushes_group, False)
        if collision_bushes and random.random() < 0.0002: # set low probability
            self.index = 0
            player.p_health = 100   # reset to 100 after battle
            animal.a_health = 100
            
            animal.url = random.choice(list(animal.animal.keys()))
            animal.image = pygame.image.load(animal.url).convert_alpha()
            description.updateMessage(str(animal.animal[animal.url]))
            msg.updateMessage("An animal appeared! Quick Use Maths to beat it!         >> Click Anywhere to Begin")
            self.battled = False

            print(">> In battle mode")
            self.state = "battle"
    
        pygame.display.update()
    
    def Battle(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.state = ""
                self.done = True
            if event.type == pygame.MOUSEBUTTONDOWN:
                if self.battled == False:
                    self.q,self.a = createMaths(self.q,self.a)
                    if self.index < len(self.q):
                        msg.updateMessage(self.q[self.index])
                    else:
                        self.index = 0
                        msg.updateMessage(self.q[self.index])
                    self.battled = True
            if event.type == pygame.KEYDOWN:
                if self.battled == True:
                    if event.unicode.isdigit(): 
                        self.userinput += event.unicode
                        if self.index < len(self.q):
                            msg.updateMessage(self.q[self.index]+self.userinput)
                    elif event.key == pygame.K_BACKSPACE:
                        if self.userinput != "":
                            self.userinput = self.userinput[:-1]
                            if self.index < len(self.q):
                                msg.updateMessage(self.q[self.index]+self.userinput)
                    elif event.key == pygame.K_RETURN:
                        if self.userinput != "":
                            correct = question.checkAnswer(self.userinput, self.a[self.index])
                            if correct:
                                msg.updateMessage(self.q[self.index]+ self.userinput+ " CORRECT! The answer is "+ str(self.a[self.index])+" >>press enter to continue")
                                animal.a_health -= 20
                                self.index += 1
                            else:
                                msg.updateMessage(self.q[self.index]+ self.userinput+ " Incorrect ioi. The answer is "+ str(self.a[self.index])+" >>press enter to continue")
                                player.p_health -= 20
                                self.index += 1
                            self.userinput = ""
                        else:
                            if self.index < len(self.q):
                                msg.updateMessage(self.q[self.index]+self.userinput)

        # game logic
        if animal.a_health == 0:
            msg.updateMessage("*** YOUR HUNT WAS SUCCESSFUL! ANIMAL ADDED TO INVENTORY!         >> Click Anywhere to Exit")
            if any(pygame.mouse.get_pressed()):
                self.inventory.append(animal.url)
                print(animal.url)
                self.state = "main"
            
        elif player.p_health == 0:
            if self.inventory != []:    # line INVENTORY CLEARED only prints if inventory had stuff in it
                msg.updateMessage("*** YOUR HUNT FAILED, all the animals escaped. INVENTORY CLEARED ioi         >> Click Anywhere to Exit")
            else:
                msg.updateMessage("*** OH NO! Don't worry, you will do great next time!         >> Click Anywhere to Exit")
            if any(pygame.mouse.get_pressed()):
                self.inventory = []
                self.state = "main"


        # drawing code
        screen.fill('#71ddee') # colour of water
        screen.blit(battlebg, (0,0))

        animal.draw(screen)
        description.draw(screen)

        msg.draw(screen)
        username.draw(screen)
        
        loadImages(player.p_health, 0, 0)
        loadImages(animal.a_health, SCREEN_WIDTH-150, SCREEN_HEIGHT-75)
        
        pygame.display.flip()


    def Inventory(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.state = ""
                self.done = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.state = "main"
            
        # drawing code
        screen.fill('#71ddee')

        draw_img(self.inventory)
        screen.blit(pygame.image.load("../graphics/health bar/inventory.png").convert_alpha(), [150, 10])
    
        pygame.display.flip()


    def state_manager(self):
        while not self.done:
            if self.state == "main":
                self.main()
            if self.state == "battle":
                self.Battle()
            if self.state == "inventory":
                self.Inventory()



# CLASSES
# classes for main game
class Player(pygame.sprite.Sprite):
    def __init__(self,pos,group):
        super().__init__(group)
        self.image = pygame.transform.scale(pygame.image.load('../graphics/player/down_stand.png').convert_alpha(), (50,80))
        self.rect = self.image.get_rect(center = pos)
        self.direction = pygame.math.Vector2()
        self.speed = 1
        self.p_health = 100

    def input(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP]:
            self.direction.y = -1
        elif keys[pygame.K_DOWN]:
            self.direction.y = 1
        else:
            self.direction.y = 0
        if keys[pygame.K_RIGHT]:
            self.direction.x = 1
        elif keys[pygame.K_LEFT]:
            self.direction.x = -1
        else:
            self.direction.x = 0

    def update(self):
        self.input()
        self.rect.center += self.direction * self.speed

        # check collisions with boundary_group
        collision = pygame.sprite.spritecollide(self, boundary_group, False)
        for col in collision:
            self.rect.center += -1 * self.direction * self.speed


class CameraGroup(pygame.sprite.Group):
    def __init__(self):
        super().__init__()
        self.display_surface = pygame.display.get_surface()
        self.half_width = self.display_surface.get_size()[0] // 2
        self.half_height = self.display_surface.get_size()[1] // 2
        self.offset = pygame.math.Vector2()
        
        # ground
        self.ground_surf = pygame.image.load("../graphics/tilemap/firstTilemap.png").convert_alpha()
        self.ground_rect = self.ground_surf.get_rect(topleft = (0,0))

    def custom_draw(self, player):
        # centre the player pos
        self.offset.x = player.rect.centerx - self.half_width
        self.offset.y = player.rect.centery - self.half_height

        # ground
        ground_offset = self.ground_rect.topleft - self.offset
        self.display_surface.blit(self.ground_surf, ground_offset)

        for sprite in sorted(self.sprites(),key = lambda sprite: sprite.rect.centery):
            offset_pos = sprite.rect.topleft - self.offset
            self.display_surface.blit(sprite.image, offset_pos)


class Tile(pygame.sprite.Sprite):
    def __init__(self,pos,surf,groups):
        super().__init__(groups)
        self.image = surf
        self.rect = self.image.get_rect(topleft = pos)

class BoundaryTile(pygame.sprite.Sprite):
    def __init__(self,pos,groups):
        super().__init__(groups)
        self.image = pygame.Surface((64, 64))
        self.image.set_alpha(0) # alpha = 0 so that it's invisible
        self.rect = self.image.get_rect(topleft = pos)

class BushTile(pygame.sprite.Sprite):
    def __init__(self, pos, groups):
        super().__init__(groups)
        self.image = pygame.Surface((64, 64))
        self.rect = self.image.get_rect(topleft=pos)

class Button():
    def __init__(self,x,y,image):
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.topleft = (x,y)

    def draw(self, screen):
        screen.blit(self.image, (self.rect.x, self.rect.y))




# classes for battles
class Text():   # text class + questions
    def __init__(self, pos):
        self.pos = pos
        self.message = "An animal appeared! Quick Use Maths to beat it!         >> Click Anywhere to Begin"
        self.font = pygame.font.SysFont('Arial', 14, True, False)
        self.colour = WHITE
        self.text = self.font.render(self.message, True, self.colour)

    def draw(self,screen):
        screen.blit(self.image, [self.pos[0],self.pos[1]])
        
    def updateMessage(self, string):
        self.message = string
        self.image = self.font.render(self.message, True, self.colour)

class Question():
    def __init__(self):
        # set up, DEFAULT values
        self.ans = 0
        self.problem = ""
        self.a = random.randint(1, 13)
        self.b = random.randint(1, 13)
        
    def Problem(self):
        userinput = ""  # clear userinput

        self.a = random.randint(1, 13)
        self.b = random.randint(1, self.a)
        operator = random.choice(["+", "-", "x"])
        if operator == "+":
            self.ans = self.a + self.b
        elif operator == "-":
            self.ans = self.a - self.b
        else:
            self.ans = self.a * self.b
        problem = f"Type your Answer: {self.a} {operator} {self.b} = "
        print(problem)
        return problem, self.ans

    def checkAnswer(self, user, actual_ans):
        if user == str(actual_ans):
            return True
        else:
            return False

class Animal():
    def __init__(self):
        self.name = "NAME"
        self.x = 400
        self.y = 200
        self.inventory = []
        self.a_health = 100
        self.url = "../graphics/animal/bear.png"
        self.animal = {
            "../graphics/animal/bear.png": "BIG BEAR\nI'm big, strong and fast! You lil human never beat me!",
            "../graphics/animal/capybara.png": "COOL CAPYBARA\nI hang out with alligators bc i'm too cool.",
            "../graphics/animal/eagle.png": "BALD EAGLE\nI'm America's national bird! The Eagle!",
            "../graphics/animal/elephant.png": "EXCELLENT ELEPHANT\nDespite being the world's largest land animal, I love to swim!",
            "../graphics/animal/fox.png": "FEARFUL FOX\nZZZZZZZZZZZZ i'm a great night-predator so I'm taking a nap right now",
            "../graphics/animal/frog.png": "FUN FROG\nI'm so fun I drink water through my skin!!!",
            "../graphics/animal/goose.png": "GOOD GOOSE\nGuguugugugugugugugu *imcomprehensible*",
            "../graphics/animal/gorilla.png": "GREAT GORILLA\nHuman! We are all gorillas! We share 98% DNA and we all love bananas!",
            "../graphics/animal/panda.png": "POPULAR PANDA\nCountries rent me for $500,000 to $1 million!",
            "../graphics/animal/tiger.png": "TINA'S TIGER\nDid you know 2023 is the year of Tiger?",
            }
        self.image = pygame.image.load(self.url).convert_alpha()

    def draw(self, screen):
        self.image = pygame.image.load(self.url).convert_alpha()
        screen.blit(self.image, [self.x,self.y])
        pygame.draw.rect(screen,'#708090', [25, 50 ,475, 50])


def loadImages(health, x, y):
    if health == 100:
        img = pygame.image.load("../graphics/health bar/5heart.png").convert_alpha()
    elif health == 80:
        img = pygame.image.load("../graphics/health bar/4heart.png").convert_alpha()
    elif health == 60:
        img = pygame.image.load("../graphics/health bar/3heart.png").convert_alpha()
    elif health == 40:
        img = pygame.image.load("../graphics/health bar/2heart.png").convert_alpha()
    elif health == 20:
        img = pygame.image.load("../graphics/health bar/1heart.png").convert_alpha()
    elif health == 0:
        img = pygame.image.load("../graphics/health bar/0heart.png").convert_alpha()
    screen.blit(img, [x,y])

def createMaths(question_lst, ans_lst):     #new questions every new hunt
    question_lst = []
    ans_lst = []
    for i in range(10):
        question = Question()
        q, ans = question.Problem()
        question_lst.append(q)
        ans_lst.append(ans)
    return question_lst, ans_lst

def draw_img(inventory):
    x = 0
    y = 100
    
    for item in inventory:
        img = pygame.image.load(item).convert_alpha()
        width = img.get_width()
        height = img.get_height()
        scaled_width = int(width * 0.3)
        scaled_height = int(height * 0.3)
        image = pygame.transform.scale(img, (scaled_width, scaled_height))
        
        if x + scaled_width >= SCREEN_WIDTH:
            y+= scaled_height
            x = 0

        screen.blit(image, [x, y])
        x += scaled_width



# VARIABLES
# main game running
game = Game()

# SCREEN
SCREEN_WIDTH = 700
SCREEN_HEIGHT = 500
screen = pygame.display.set_mode((SCREEN_WIDTH,SCREEN_HEIGHT))
battlebg = pygame.transform.scale(pygame.image.load("../graphics/battlebg.png"),(SCREEN_WIDTH,SCREEN_HEIGHT))
pygame.display.set_caption("Wild Maths Hunters!")

##### Colours #####
BLACK = (  0,   0,   0)
WHITE = (255, 255, 255)
RED   = (255,   0,   0)
BLUE  = (  0,   0, 255)
GREEN = (  0, 255,   0)

# tile map and layers
camera_group = CameraGroup()
player = Player((325,225),camera_group)

tmx_data = load_pygame("../graphics/tilemap/firstTilemap.tmx")
sprite_group = pygame.sprite.Group()
boundary_group = pygame.sprite.Group()
bushes_group = pygame.sprite.Group()

for layer in tmx_data.visible_layers:
    if hasattr(layer,"data"):
        for x,y,surf in layer.tiles():
            pos = (x*64, y*64)
            if layer.name == "Boundary":
                BoundaryTile(pos = pos, groups=[sprite_group, boundary_group])
            elif layer.name == "Bushes":
                BushTile(pos, bushes_group)
            else:
                Tile(pos = pos, surf = surf, groups = sprite_group)

for obj in tmx_data.objects:
    pos = obj.x, obj.y
    if obj.image:
        Tile(pos = pos, surf = obj.image, groups = [sprite_group, boundary_group])


# HEALTH POINTS
a_health = 100  # a for animal, p for player
p_health = 100

# INVENTORY
bag = Button(475,0,pygame.image.load("../graphics/health bar/button.png").convert_alpha())

# BATTLE
msg = Text((10,420))
msg.image = msg.font.render(msg.message, True, WHITE)

index = 0 # for question list
userinput = ""
question = Question()
username = Text((150,20))
username.updateMessage(" <==== YOU")

# ANIMAL
animal = Animal()

description = Text((25,50))
description.font = pygame.font.SysFont('Arial', 12, True, False)
description.text = description.font.render(description.message, True, WHITE)




# GAME LOOP
while not game.done:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game.done = True
            
    game.state_manager()
    
    clock.tick(60)

pygame.quit()

