<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="objects" tilewidth="128" tileheight="128" tilecount="21" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="128" height="128" source="obstacles/02.png"/>
 </tile>
 <tile id="1">
  <image width="128" height="128" source="obstacles/03.png"/>
 </tile>
 <tile id="2">
  <image width="128" height="128" source="obstacles/04.png"/>
 </tile>
 <tile id="3">
  <image width="128" height="128" source="obstacles/05.png"/>
 </tile>
 <tile id="4">
  <image width="128" height="128" source="obstacles/06.png"/>
 </tile>
 <tile id="5">
  <image width="128" height="128" source="obstacles/07.png"/>
 </tile>
 <tile id="6">
  <image width="128" height="128" source="obstacles/08.png"/>
 </tile>
 <tile id="7">
  <image width="128" height="128" source="obstacles/09.png"/>
 </tile>
 <tile id="8">
  <image width="128" height="128" source="obstacles/10.png"/>
 </tile>
 <tile id="9">
  <image width="64" height="128" source="obstacles/11.png"/>
 </tile>
 <tile id="10">
  <image width="64" height="128" source="obstacles/12.png"/>
 </tile>
 <tile id="11">
  <image width="64" height="128" source="obstacles/13.png"/>
 </tile>
 <tile id="12">
  <image width="64" height="128" source="obstacles/14.png"/>
 </tile>
 <tile id="13">
  <image width="128" height="128" source="obstacles/15.png"/>
 </tile>
 <tile id="14">
  <image width="128" height="128" source="obstacles/16.png"/>
 </tile>
 <tile id="15">
  <image width="128" height="128" source="obstacles/17.png"/>
 </tile>
 <tile id="16">
  <image width="128" height="128" source="obstacles/18.png"/>
 </tile>
 <tile id="17">
  <image width="128" height="128" source="obstacles/19.png"/>
 </tile>
 <tile id="18">
  <image width="128" height="128" source="obstacles/20.png"/>
 </tile>
 <tile id="19">
  <image width="128" height="128" source="obstacles/0.png"/>
 </tile>
 <tile id="20">
  <image width="128" height="128" source="obstacles/01.png"/>
 </tile>
</tileset>
