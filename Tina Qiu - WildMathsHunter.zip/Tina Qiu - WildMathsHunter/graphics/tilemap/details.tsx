<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="details" tilewidth="64" tileheight="64" tilecount="80" columns="16">
 <image source="details.png" width="1024" height="320"/>
</tileset>
